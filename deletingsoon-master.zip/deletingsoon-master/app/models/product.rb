class Product < ApplicationRecord
	has_many :order
end
